export default [

    { title: 'Користувачі', to: { name: 'users' }, icon: { icon: 'tabler-file' } },
    { title: 'Промокоди', to: { name: 'promocodes' }, icon: { icon: 'tabler-file' } },

    // { title: 'Users',        to: { name: 'users' },        icon: 'tabler-users' },
    // { title: 'User Profile', to: { name: 'user-profile' }, icon: 'tabler-user' },
    // { title: 'Promocodes',   to: { name: 'promocodes' },   icon: 'tabler-discount-2' },


]
