export default [
    {
        title: 'Home',
        to: {name: 'root'},
        icon: {icon: 'tabler-smart-home'},
    },
    {
        title: 'Second page',
        to: {name: 'second-page'},
        icon: {icon: 'tabler-file'},
    },
    {
        title: 'Users',
        to: {name: 'users-page'},
        icon: {icon: 'tabler-file'},
    },

    // { title: 'Users',        to: { name: 'users' },        icon: 'tabler-users' },
    // { title: 'User Profile', to: { name: 'user-profile' }, icon: 'tabler-user' },
    // { title: 'Promocodes',   to: { name: 'promocodes' },   icon: 'tabler-discount-2' },


]
