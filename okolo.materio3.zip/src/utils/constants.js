export const COOKIE_MAX_AGE_1_YEAR = 365 * 24 * 60 * 60
