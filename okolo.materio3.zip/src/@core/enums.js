export const Skins = {
  Default: 'default',
  Bordered: 'bordered',
}
export const Theme = {
  Light: 'light',
  Dark: 'dark',
  System: 'system',
}
export const Layout = {
  Vertical: 'vertical',
  Horizontal: 'horizontal',
  Collapsed: 'collapsed',
}
export const Direction = {
  Ltr: 'ltr',
  Rtl: 'rtl',
}
