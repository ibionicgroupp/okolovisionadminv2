// import { createRouter, createWebHistory } from 'vue-router'
//
// const routes = [
//     {
//         path: '/users',
//         name: 'users',
//         component: () => import('@/views/users.vue'),
//         meta: { layout: 'default' },
//     },
//     {
//         path: '/user-profile',
//         name: 'user-profile',
//         component: () => import('@/views/UserProfile.vue'),
//         meta: { layout: 'default' },
//     },
//     {
//         path: '/promocodes',
//         name: 'promocodes',
//         component: () => import('@/views/Promocodes.vue'),
//         meta: { layout: 'default' },
//     },
//     {
//         path: '/login',
//         name: 'login',
//         component: () => import('@/views/Login.vue'),
//         meta: { layout: 'blank' },
//     },
// ]
//
// const router = createRouter({
//     history: createWebHistory(import.meta.env.BASE_URL),
//     routes,
// })
//
// export default router
